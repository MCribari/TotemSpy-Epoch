LoadAddOn("Blizzard_CombatText")

local band = bit.band

local COMBATLOG_OBJECT_TYPE_PLAYER = COMBATLOG_OBJECT_TYPE_PLAYER
local COMBATLOG_OBJECT_REACTION_HOSTILE = COMBATLOG_OBJECT_REACTION_HOSTILE

local CombatText_AddMessage = CombatText_AddMessage

local totemDB = {
	8143, -- Tremor Totem
	8170, -- Cleansing Totem
	8177, -- Grounding Totem
	16190, -- Mana Tide Totem
}

local EventHandler = CreateFrame("Frame")

EventHandler:RegisterEvent("PLAYER_ENTERING_WORLD")

EventHandler:SetScript("OnEvent", function(self, event, ...)
	if event == "COMBAT_LOG_EVENT_UNFILTERED" then
		local _, eventType, _, _, srcFlags, _, _, _, spellId, spellName = ...
		
		if eventType == "SPELL_SUMMON" then
			local isPlayer = band(srcFlags, COMBATLOG_OBJECT_TYPE_PLAYER) > 0
			local isHostile = band(srcFlags, COMBATLOG_OBJECT_REACTION_HOSTILE) > 0
			
			if isPlayer and isHostile then
				for i = 1, #totemDB do
					if totemDB[i] == spellId then
						CombatText_AddMessage(spellName, nil, 1, 0, 0, "crit")
						PlaySound(8959)						
						break
					end
				end
			end
		end
		
	elseif event == "PLAYER_ENTERING_WORLD" then
		local _, instanceType = IsInInstance()
		
		if instanceType == "arena" then
			self:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
		elseif self:IsEventRegistered("COMBAT_LOG_EVENT_UNFILTERED") then
			self:UnregisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
		end
	end
end)